# Cheat for owo

* ### [Download Lastest Release](https://github.com/ahihiyou20/discord-selfbot-owo-bot/tags)
[![GitHub issues](https://img.shields.io/github/issues/ahihiyou20/discord-selfbot-owo-bot?label=Open%20%C4%B0ssues)](https://github.com/ahihiyou20/discord-selfbot-owo-bot/issues)
[![GitHub forks](https://img.shields.io/github/forks/ahihiyou20/discord-selfbot-owo-bot)](https://github.com/ahihiyou20/discord-selfbot-owo-bot/network)
[![GitHub stars](https://img.shields.io/github/stars/ahihiyou20/discord-selfbot-owo-bot)](https://github.com/ahihiyou20/discord-selfbot-owo-bot/stargazers)


How to setup?
**Install discum (Use The Following Command):**
```
python -m pip install --user --upgrade git+https://github.com/Merubokkusu/Discord-S.C.U.M.git#egg=discum
```
**Then Run "main.py", Enter Your Token And Channel ID And Other Settings. If You Don't Know How To Get Channel ID: https://support.discord.com/hc/en-us/articles/206346498-Kullan%C4%B1c%C4%B1-Sunucu-Mesaj-ID-sini-Nerden-Bulurum-**

**You Can Use This Bot On Windows, Linux And Android With "Termux" App.**

**Install Termux If You Want To Use This Bot On Android And Use Those Command ^^**:

**Termux Website: https://termux.com/**


**All Available Settings:**

**> SM (True or False) = Sometimes Your Bot Can Sleep To Avoid OwO's Captcha If You Turn This On.**

**> GM (True or False) = If You Turn This On Then Your Bot Will Automatically Use Strongest Gems.**

**> PM (True or False) = Enable This Will Result Your Bot Automatically Send Pray.**

**> OM (True or False) = Send "owo" Sometimes If You Turn It On.**


**Your Account Must Have A Valid OwO Profile Already, This Bot Can't Run Efficiency On New Generated Accounts.**

**You Need A Team (Army) And Some Gems Before Start Botting, That's Because This Bot cant' Build A Perfect Account From Zero Yet.**

**Feel Free To Open Issue On Github Or The Support Discord Server**:
https://discord.gg/3kTrhbBVQm

**Lastest version: See in version.txt**

**Note: This repository is forked from Nizel-sudo-do discord-selfbot-owo-bot repository. I fixed and upgrade his code. So im NOT the owner of this code but at least im still update this repository every week.**

**Note 2: This Repository Is For Educational Purposes Only. Selfbot are against Discord's ToS and against OwO's Rules! Use It At Your Own Risk!**
